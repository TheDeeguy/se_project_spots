# Spots

This is a website where images are shared.

## Description

This is a responsive website where images can be shared via the world wide web.

## Tech Stack

-HTML
-CSS
-Figma

## Deployment

This webpage is deployed to github pages.

[-Deployment Link:](https://thedeeguy.github.io/se_project_spots/)

## {_video description:}
 (https://drive.google.com/file/d/1jbx3b5N7mWmQuA2aQvtKu-AjJb0XdaLP/view?usp=drive_link)
